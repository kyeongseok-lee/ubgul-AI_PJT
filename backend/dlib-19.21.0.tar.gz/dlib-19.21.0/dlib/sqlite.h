// Copyright (C) 2011  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_SQLiTE_HEADER
#define DLIB_SQLiTE_HEADER

#include "sqlite/sqlite_tools.h"

#endif // DLIB_SVm_HEADER



